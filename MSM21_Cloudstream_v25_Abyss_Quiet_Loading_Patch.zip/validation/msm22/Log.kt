package android.util
object Log { fun i(tag: String, message: String): Int = 0; fun w(tag: String, message: String): Int = 0 }
