# Nuvio Manifest Fix

Fixes the repository manifest root from the old provider-array format to the current repository-object format:

```json
{
  "name": "Luckez12 Plugins",
  "version": "1.0.0",
  "scrapers": []
}
```

Also updates the KissKH registration script, manifest validator, and bootstrap workflow.
