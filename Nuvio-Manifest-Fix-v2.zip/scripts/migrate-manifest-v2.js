const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "..", "manifest.json");
const current = JSON.parse(fs.readFileSync(file, "utf8"));

if (!Array.isArray(current)) {
  console.log("Manifest already uses repository object format.");
  process.exit(0);
}

const migrated = {
  name: "Luckez12 Plugins",
  version: "1.0.0",
  scrapers: current
};

fs.writeFileSync(file, JSON.stringify(migrated, null, 2) + "\n");
console.log(`Migrated ${current.length} scraper(s) to repository object format.`);
