const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "..", "manifest.json");

let manifest = {
  name: "Luckez12 Plugins",
  version: "1.0.0",
  scrapers: []
};

if (fs.existsSync(file)) {
  const current = JSON.parse(fs.readFileSync(file, "utf8"));

  // Auto-migrate the old array format.
  if (Array.isArray(current)) {
    manifest.scrapers = current;
  } else if (current && typeof current === "object") {
    manifest = current;
    if (!Array.isArray(manifest.scrapers)) manifest.scrapers = [];
  }
}

const entry = {
  id: "kisskh",
  name: "KissKH",
  description: "KissKH Asian drama and movie provider",
  version: "1.0.1",
  author: "Luckez12",
  supportedTypes: ["movie", "tv"],
  filename: "providers/kisskh.js",
  enabled: true,
  logo: "https://www.google.com/s2/favicons?domain=kisskh.do&sz=128",
  contentLanguage: ["en", "ko", "zh", "ja", "th"],
  formats: ["m3u8", "mp4"],
  limited: false,
  disabledPlatforms: [],
  supportsExternalPlayer: true
};

const index = manifest.scrapers.findIndex(x => x && x.id === entry.id);
if (index >= 0) manifest.scrapers[index] = { ...manifest.scrapers[index], ...entry };
else manifest.scrapers.push(entry);

fs.writeFileSync(file, JSON.stringify(manifest, null, 2) + "\n");
console.log("Registered KissKH using Nuvio repository manifest format.");
