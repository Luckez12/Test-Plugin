const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const manifest = JSON.parse(
  fs.readFileSync(path.join(root, "manifest.json"), "utf8")
);

if (!manifest || Array.isArray(manifest) || typeof manifest !== "object") {
  throw new Error("manifest.json root must be a JSON object");
}

if (!manifest.name) throw new Error("manifest.json missing repository name");
if (!manifest.version) throw new Error("manifest.json missing repository version");

if (!Array.isArray(manifest.scrapers)) {
  throw new Error("manifest.json must contain a scrapers array");
}

const ids = new Set();

for (const item of manifest.scrapers) {
  for (const key of ["id", "name", "version", "filename"]) {
    if (!item[key]) throw new Error(`Scraper entry missing ${key}`);
  }

  if (ids.has(item.id)) throw new Error(`Duplicate scraper id: ${item.id}`);
  ids.add(item.id);

  const file = path.join(root, item.filename);

  if (!fs.existsSync(file)) {
    throw new Error(`Provider file missing: ${item.filename}`);
  }

  delete require.cache[require.resolve(file)];
  const provider = require(file);

  if (!provider || typeof provider.getStreams !== "function") {
    throw new Error(`${item.filename} must export getStreams()`);
  }
}

console.log(
  `Manifest valid: ${manifest.name}, ${manifest.scrapers.length} scraper(s)`
);
