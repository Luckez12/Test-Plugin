const PROVIDER = "PencuriMovie";
const VERSION = "1.0.8";
const BASE = "https://ww44.pencurimovie.baby";
const TMDB_BASE = "https://api.themoviedb.org/3";
const TMDB_API_KEY = "1865f43a0549ca50d341dd9ab8b29f49";
const USER_AGENT = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0 Mobile Safari/537.36";
const PLAYMATE_USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64; rv:153.0) Gecko/20100101 Firefox/153.0";

function getCheerio() {
  return require("cheerio-without-node-native");
}

function fetchResponse(url, options) {
  return fetch(url, options || {}).then(function (res) {
    if (!res || !res.ok) {
      throw new Error("HTTP " + (res ? res.status : "unknown") + " " + url);
    }
    return res.text().then(function (text) {
      return {
        text: text,
        url: res.url || url,
        status: res.status
      };
    });
  });
}

function fetchText(url, options) {
  return fetchResponse(url, options).then(function (x) { return x.text; });
}

function fetchJson(url, options) {
  return fetchText(url, options).then(function (text) {
    return JSON.parse(String(text || "").replace(/^\uFEFF/, ""));
  });
}

function originOf(url) {
  var m = String(url || "").match(/^(https?:\/\/[^\/]+)/i);
  return m ? m[1] : String(url || "").replace(/\/+$/, "");
}

function absoluteUrl(base, value) {
  var raw = String(value || "")
    .trim()
    .replace(/&amp;/g, "&")
    .replace(/&#038;/g, "&")
    .replace(/\\\//g, "/")
    .replace(/^['\"]|['\"]$/g, "");

  if (!raw || raw === "#" || /^javascript:/i.test(raw)) return "";
  if (/^https?:\/\//i.test(raw)) return raw;
  if (/^\/\//.test(raw)) return "https:" + raw;

  var root = originOf(base);
  if (raw.charAt(0) === "/") return root + raw;

  var cleanBase = String(base || "").split("#")[0].split("?")[0];
  cleanBase = cleanBase.substring(0, cleanBase.lastIndexOf("/") + 1);
  return cleanBase + raw;
}

function normalizeTitle(value) {
  var text = String(value || "").toLowerCase();
  try {
    text = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  } catch (_) {}
  return text
    .replace(/&/g, " and ")
    .replace(/[’'`]/g, "")
    .replace(/\[[^\]]+\]/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function slugifyTitle(value) {
  var text = String(value || "").trim().toLowerCase();
  try {
    text = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  } catch (_) {}
  return text
    .replace(/&/g, " and ")
    .replace(/[’'`]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .replace(/-+/g, "-");
}

function stripYear(value) {
  return String(value || "")
    .replace(/\s*\(((?:19|20)\d{2})\)\s*$/i, "")
    .trim();
}

function yearFromText(value) {
  var m = String(value || "").match(/(?:\(|\b)((?:19|20)\d{2})(?:\)|\b)/);
  return m ? Number(m[1]) : null;
}

function getTmdbDetails(tmdbId, mediaType) {
  var type = mediaType === "tv" ? "tv" : "movie";
  var url = TMDB_BASE + "/" + type + "/" + encodeURIComponent(tmdbId) +
    "?api_key=" + TMDB_API_KEY + "&append_to_response=alternative_titles";

  return fetchJson(url, {
    headers: {
      "Accept": "application/json",
      "User-Agent": USER_AGENT
    }
  }).then(function (data) {
    var altRoot = data.alternative_titles || {};
    var altItems = type === "movie"
      ? (Array.isArray(altRoot.titles) ? altRoot.titles : [])
      : (Array.isArray(altRoot.results) ? altRoot.results : []);

    return {
      title: type === "movie"
        ? (data.title || data.original_title || "")
        : (data.name || data.original_name || ""),
      originalTitle: data.original_title || data.original_name || "",
      year: String(data.release_date || data.first_air_date || "").slice(0, 4),
      alternativeTitles: altItems.map(function (x) {
        return x && x.title ? String(x.title).trim() : "";
      }).filter(Boolean)
    };
  });
}

function acceptedTitleSet(details) {
  var set = {};
  [details.title, details.originalTitle]
    .concat(details.alternativeTitles || [])
    .filter(Boolean)
    .forEach(function (title) {
      var n = normalizeTitle(title);
      if (n) set[n] = true;
    });
  return set;
}

function parsePageIdentity(html) {
  var cheerio = getCheerio();
  var $ = cheerio.load(String(html || ""));
  var rawTitle = String(
    $("div.mvic-desc h3").first().text() ||
    $("meta[property='og:title']").attr("content") ||
    $("title").first().text() ||
    ""
  ).replace(/\s+/g, " ").trim();

  rawTitle = rawTitle
    .replace(/\s*[-|]\s*Pencuri\s*Movie.*$/i, "")
    .trim();

  var year = yearFromText(rawTitle);
  if (!year) {
    $("div.mvic-info p").each(function (_, el) {
      if (year) return;
      var text = String($(el).text() || "").replace(/\s+/g, " ").trim();
      if (/Release\s*:/i.test(text)) year = yearFromText(text);
    });
  }

  return {
    title: stripYear(rawTitle),
    rawTitle: rawTitle,
    year: year
  };
}

function validatePage(html, details, mediaType) {
  var identity = parsePageIdentity(html);
  if (!identity.title) return null;

  var accepted = acceptedTitleSet(details);
  if (!accepted[normalizeTitle(identity.title)]) return null;

  var targetYear = Number(details.year || 0);
  var itemYear = Number(identity.year || 0);
  if (mediaType === "movie" && targetYear && itemYear && Math.abs(targetYear - itemYear) > 1) {
    return null;
  }

  return identity;
}

function tryDirectPage(details, mediaType) {
  var slug = slugifyTitle(details.title || details.originalTitle || "");
  var year = String(details.year || "").trim();
  if (!slug) return Promise.resolve(null);

  var paths = mediaType === "movie"
    ? ["/" + slug + (year ? "-" + year : "") + "/"]
    : [
        "/series/" + slug + (year ? "-" + year : "") + "/",
        "/series/" + slug + "/",
        "/" + slug + (year ? "-" + year : "") + "/"
      ];

  var index = 0;
  function next() {
    if (index >= paths.length) return Promise.resolve(null);
    var url = BASE + paths[index++];
    return fetchText(url, {
      headers: {
        "Accept": "text/html,*/*",
        "Referer": BASE + "/",
        "User-Agent": USER_AGENT
      }
    }).then(function (html) {
      var identity = validatePage(html, details, mediaType);
      if (!identity) return next();
      console.log("[PencuriMovie] fast title='" + identity.rawTitle + "' url=" + url);
      return {
        title: identity.title,
        rawTitle: identity.rawTitle,
        year: identity.year,
        url: url,
        mediaType: mediaType,
        html: html
      };
    }).catch(function () {
      return next();
    });
  }

  return next();
}

function parseSearchResults(html, pageUrl) {
  var cheerio = getCheerio();
  var $ = cheerio.load(html);
  var results = [];

  $("div.ml-item").each(function (_, element) {
    var box = $(element);
    var a = box.find("a[href]").first();
    var href = absoluteUrl(pageUrl, a.attr("href"));
    if (!href || href.indexOf("pencurimovie") === -1) return;

    var rawTitle = String(
      a.attr("oldtitle") ||
      a.attr("title") ||
      box.find("h2").first().text() ||
      ""
    ).replace(/\s+/g, " ").trim();
    if (!rawTitle) return;

    var eps = box.find("span.mli-eps").length > 0;
    var isTv = eps || /\/series\//i.test(href);

    results.push({
      title: stripYear(rawTitle),
      rawTitle: rawTitle,
      year: yearFromText(rawTitle),
      url: href,
      mediaType: isTv ? "tv" : "movie"
    });
  });

  return results;
}

function scoreCandidate(item, details, mediaType) {
  if (!item || item.mediaType !== mediaType) return null;
  var accepted = acceptedTitleSet(details);
  var title = normalizeTitle(item.title);
  if (!accepted[title]) return null;

  var targetYear = Number(details.year || 0);
  var itemYear = Number(item.year || 0);
  if (mediaType === "movie" && targetYear && itemYear && Math.abs(targetYear - itemYear) > 1) {
    return null;
  }

  var score = 100;
  if (title === normalizeTitle(details.title)) score += 40;
  if (targetYear && itemYear && targetYear === itemYear) score += 30;
  return score;
}

function searchSite(query) {
  var url = BASE + "/?s=" + encodeURIComponent(query);
  return fetchText(url, {
    headers: {
      "Accept": "text/html,*/*",
      "Referer": BASE + "/",
      "User-Agent": USER_AGENT
    }
  }).then(function (html) {
    return parseSearchResults(html, url);
  });
}

function findBestTitle(details, mediaType) {
  var queries = [];
  function add(v) {
    v = String(v || "").trim();
    if (v && queries.indexOf(v) === -1) queries.push(v);
  }
  add(details.title);
  add(details.originalTitle);
  (details.alternativeTitles || []).slice(0, 2).forEach(add);

  var index = 0;
  function next() {
    if (index >= queries.length) return Promise.resolve(null);
    var query = queries[index++];
    return searchSite(query).then(function (items) {
      var ranked = items.map(function (item) {
        return { item: item, score: scoreCandidate(item, details, mediaType) };
      }).filter(function (x) {
        return typeof x.score === "number";
      }).sort(function (a, b) {
        return b.score - a.score;
      });

      if (ranked.length) {
        console.log("[PencuriMovie] matched title='" + ranked[0].item.rawTitle + "' url=" + ranked[0].item.url);
        return ranked[0].item;
      }
      return next();
    }).catch(function () {
      return next();
    });
  }

  return next();
}

function findTitle(details, mediaType) {
  return tryDirectPage(details, mediaType).then(function (item) {
    if (item) return item;
    return findBestTitle(details, mediaType);
  });
}

function findEpisodeUrl(html, pageUrl, season, episode) {
  var cheerio = getCheerio();
  var $ = cheerio.load(html);
  var wantedSeason = Number(season || 1);
  var wantedEpisode = Number(episode || 1);
  var found = "";

  $("div.tvseason").each(function (_, seasonEl) {
    if (found) return;
    var box = $(seasonEl);
    var seasonText = String(box.find("strong").first().text() || "");
    var sm = seasonText.match(/Season\s*(\d+)/i);
    var currentSeason = sm ? Number(sm[1]) : 1;
    if (currentSeason !== wantedSeason) return;

    box.find("div.les-content a[href]").each(function (_, aEl) {
      if (found) return;
      var a = $(aEl);
      var text = String(a.text() || "").replace(/\s+/g, " ").trim();
      var em = text.match(/Episode\s*(\d+)/i);
      if (!em) em = String(a.attr("href") || "").match(/(?:episode|ep)[-_\/]?(\d+)/i);
      var currentEpisode = em ? Number(em[1]) : null;
      if (currentEpisode === wantedEpisode) {
        found = absoluteUrl(pageUrl, a.attr("href"));
      }
    });
  });

  return found;
}

function loadPlaybackPage(item, mediaType, season, episode) {
  var rootPromise = item && item.html
    ? Promise.resolve(item.html)
    : fetchText(item.url, {
        headers: {
          "Accept": "text/html,*/*",
          "Referer": BASE + "/",
          "User-Agent": USER_AGENT
        }
      });

  return rootPromise.then(function (html) {
    if (mediaType === "movie") {
      return { url: item.url, html: html };
    }

    var episodeUrl = findEpisodeUrl(html, item.url, season, episode);
    if (!episodeUrl) {
      console.log("[PencuriMovie] episode not found S" + season + "E" + episode);
      return null;
    }

    console.log("[PencuriMovie] episode url=" + episodeUrl);
    return fetchText(episodeUrl, {
      headers: {
        "Accept": "text/html,*/*",
        "Referer": item.url,
        "User-Agent": USER_AGENT
      }
    }).then(function (episodeHtml) {
      return { url: episodeUrl, html: episodeHtml };
    });
  });
}

function cleanCandidateUrl(value) {
  return String(value || "")
    .trim()
    .replace(/^['\"]|['\"]$/g, "")
    .replace(/\\\//g, "/")
    .replace(/&amp;/g, "&")
    .replace(/&#038;/g, "&");
}

function isBlockedFrame(url) {
  var lower = String(url || "").toLowerCase();
  return !/^https?:\/\//i.test(url) ||
    /youtube\.com|youtu\.be|google\.com\/recaptcha|doubleclick|googlesyndication|facebook\.com|instagram\.com|t\.me\//i.test(lower) ||
    /\.(?:jpg|jpeg|png|gif|webp|svg|css|js|woff2?|ttf|ico)(?:[?#]|$)/i.test(lower);
}

function extractUrlsFromScripts(html) {
  var clean = String(html || "")
    .replace(/\\u0026/gi, "&")
    .replace(/\\\//g, "/");
  var out = {};
  var patterns = [
    /(?:src|file|url|embed|video|player|data-src|data-video|data-url)["']?\s*[:=]\s*["'](https?:[^"'\s<]+)["']/ig,
    /(https?:\/\/[^\s"'<>\\]+)/ig
  ];
  patterns.forEach(function (regex) {
    var m;
    while ((m = regex.exec(clean))) {
      var candidate = m[1] || m[0];
      if (candidate) out[candidate] = true;
      if (Object.keys(out).length >= 40) break;
    }
  });
  return Object.keys(out);
}

function collectEmbedUrls(html, pageUrl) {
  var cheerio = getCheerio();
  var $ = cheerio.load(html);
  var found = {};

  function add(raw, label) {
    var cleaned = cleanCandidateUrl(raw);
    var url = absoluteUrl(pageUrl, cleaned);
    if (!url || url === pageUrl || isBlockedFrame(url)) return;
    if (originOf(url) === originOf(pageUrl) && url.split("#")[0] === pageUrl.split("#")[0]) return;
    if (!found[url]) found[url] = label || "Server";
  }

  // Read tab targets first so website server numbers survive generic discovery.
  $(".player_nav .idTabs a[href]").each(function (_, el) {
    var tab = $(el);
    var target = String(tab.attr("href") || "");
    if (!/^#[A-Za-z0-9_-]+$/.test(target)) return;
    var label = tab.closest("li").find(".les-title strong").first().text() || tab.text() || "Server";
    $(target).find("iframe, [data-src], [data-video], [data-url], [data-embed], [data-link]").each(function (_, frame) {
      var node = $(frame);
      ["data-src", "src", "data-video", "data-url", "data-embed", "data-link"].forEach(function (attr) {
        add(node.attr(attr), String(label).replace(/\s+/g, " ").trim());
      });
    });
  });

  var selectors = [
    "div.movieplay iframe",
    "div.movieplay [data-src]",
    "div.movieplay [data-video]",
    "div.movieplay [data-url]",
    "div.movieplay [data-embed]",
    "div.movieplay [data-link]",
    "div#movieplay iframe",
    "div#movieplay [data-src]",
    "div#movieplay [data-video]",
    "div#movieplay [data-url]",
    "div#player iframe",
    "div#player [data-src]",
    "div#player [data-video]",
    "div#player [data-url]",
    "div.player iframe",
    "div.player [data-src]",
    "div.player [data-video]",
    "div.player [data-url]",
    "div.playbox iframe",
    "div.playbox [data-src]",
    "[id*=server] iframe",
    "[id*=server] [data-src]",
    "[id*=server] [data-video]",
    "[id*=server] [data-url]",
    "[class*=server] iframe",
    "[class*=server] [data-src]",
    "[class*=server] [data-video]",
    "[class*=server] [data-url]"
  ].join(", ");

  $(selectors).each(function (_, el) {
    var node = $(el);
    var label = String(
      node.attr("title") ||
      node.attr("data-name") ||
      node.closest("li,div").find("span,strong").first().text() ||
      "Server"
    ).replace(/\s+/g, " ").trim();

    [
      node.attr("data-src"),
      node.attr("src"),
      node.attr("data-video"),
      node.attr("data-url"),
      node.attr("data-embed"),
      node.attr("data-link"),
      node.attr("data-player"),
      node.attr("href")
    ].forEach(function (v) { add(v, label); });
  });

  if (!Object.keys(found).length) {
    $("iframe, [data-src], [data-video], [data-url], [data-embed], [data-link], [data-player]").each(function (_, el) {
      var node = $(el);
      [
        node.attr("data-src"), node.attr("src"), node.attr("data-video"),
        node.attr("data-url"), node.attr("data-embed"), node.attr("data-link"),
        node.attr("data-player")
      ].forEach(function (v) { add(v, "Server"); });
    });
  }

  if (!Object.keys(found).length) {
    extractUrlsFromScripts(html).forEach(function (url) { add(url, "Script"); });
  }

  return Object.keys(found).map(function (url) {
    return { url: url, label: found[url] };
  });
}

function hostOf(url) {
  var m = String(url || "").match(/^https?:\/\/([^\/?#]+)/i);
  return m ? m[1].toLowerCase() : "";
}

function decodeHtmlEntities(value) {
  return String(value || "")
    .replace(/&amp;/g, "&")
    .replace(/&#038;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

function isLikelyStreamUrl(raw) {
  var value = String(raw || "").toLowerCase();
  if (!/^https?:\/\//i.test(String(raw || ""))) return false;
  return /\.(?:m3u8|mp4|m4v|mkv|webm)(?:[?#]|$)/i.test(value) ||
    value.indexOf("/sora/") >= 0 ||
    value.indexOf("manifest.m3u8") >= 0 ||
    value.indexOf("master.m3u8") >= 0 ||
    /[?&](?:mime|type)=video/i.test(value);
}

function mediaUrlsFromText(text, baseUrl) {
  var input = decodeHtmlEntities(String(text || ""))
    .replace(/\\u0026/gi, "&")
    .replace(/\\\//g, "/");
  var found = {};

  function add(raw) {
    raw = String(raw || "").trim().replace(/^["']|["']$/g, "").replace(/["'\\]+$/g, "");
    var url = absoluteUrl(baseUrl, raw);
    if (url && isLikelyStreamUrl(url)) found[url] = true;
  }

  (input.match(/https?:\/\/[^\s"'<>\\]+/ig) || []).forEach(add);
  (input.match(/\/\/[a-z0-9.-]+\/[^\s"'<>\\]+/ig) || []).forEach(add);
  return Object.keys(found);
}

function unpackPacker(source) {
  var text = String(source || "");
  if (text.indexOf("eval(function(p,a,c,k,e,d)") === -1) return text;
  var re = /eval\(function\(p,a,c,k,e,d\)\{.*?\}\('([\s\S]*?)',(\d+),(\d+),'([\s\S]*?)'\.split\('\|'\)/;
  var match = re.exec(text);
  if (!match) return text;

  var payload = match[1].replace(/\\'/g, "'").replace(/\\\\/g, "\\");
  var radix = Number(match[2]);
  var count = Number(match[3]);
  var symtab = match[4].split("|");

  function encodeBase(num, base) {
    var chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (num < base) return chars.charAt(num);
    return encodeBase(Math.floor(num / base), base) + chars.charAt(num % base);
  }

  for (var i = count - 1; i >= 0; i--) {
    if (!symtab[i]) continue;
    var word = encodeBase(i, radix);
    payload = payload.replace(new RegExp("\\b" + word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "g"), symtab[i]);
  }
  return payload;
}

function resolvePlaymate(url) {
  if (!/playmate\.to/i.test(url)) return Promise.resolve([]);
  var clean = String(url).split("#")[0].split("?")[0].replace(/\/+$/, "");
  var id = clean.substring(clean.lastIndexOf("/") + 1);
  if (!id) return Promise.resolve([]);

  return fetchJson("https://playmate.to/api/s", {
    method: "POST",
    headers: {
      "Accept": "application/json,*/*",
      "Content-Type": "application/json",
      "User-Agent": PLAYMATE_USER_AGENT
    },
    body: JSON.stringify({ c: id, d: "web" })
  }).then(function (data) {
    var streamUrl = String(data && data.sx || "").trim();
    if (!/^https?:\/\//i.test(streamUrl)) return [];
    return [{
      url: streamUrl,
      label: "Playmate",
      noReferer: true,
      headers: { "Accept": "*/*", "User-Agent": PLAYMATE_USER_AGENT }
    }];
  }).catch(function () { return []; });
}

function randomToken(length) {
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var out = "";
  for (var i = 0; i < length; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
  return out;
}

function resolveDood(url, referer) {
  if (!/(?:dood|dsvplay|ds2play|vide0\.net|myvidplay)/i.test(url)) return Promise.resolve([]);
  var embedUrl = String(url).replace("/d/", "/e/");

  return fetchResponse(embedUrl, {
    headers: {
      "Accept": "text/html,*/*",
      "Referer": referer || originOf(embedUrl) + "/",
      "User-Agent": USER_AGENT
    }
  }).then(function (response) {
    var finalEmbedUrl = response.url || embedUrl;
    var host = originOf(finalEmbedUrl);
    var passMatch = response.text.match(/\/pass_md5\/[^'"\s<]+/i);
    if (!passMatch) return [];
    var passUrl = /^https?:\/\//i.test(passMatch[0]) ? passMatch[0] : host + passMatch[0];
    var token = passUrl.substring(passUrl.lastIndexOf("/") + 1);
    if (!token) return [];

    return fetchText(passUrl, {
      headers: { "Accept": "*/*", "Referer": finalEmbedUrl, "User-Agent": USER_AGENT }
    }).then(function (prefix) {
      var base = String(prefix || "").trim();
      if (!/^https?:\/\//i.test(base)) return [];
      var finalUrl = base + randomToken(10) + "?token=" + encodeURIComponent(token);
      return [{
        url: finalUrl,
        referer: host + "/",
        label: "Dood",
        headers: { "Accept": "*/*", "Referer": host + "/", "User-Agent": USER_AGENT }
      }];
    });
  }).catch(function () { return []; });
}

function resolveMixDrop(url, referer) {
  if (!/(?:mixdrop|mxdrop|mdy48tn97)/i.test(url)) return Promise.resolve([]);
  var embedUrl = String(url).replace("/f/", "/e/");
  return fetchText(embedUrl, {
    headers: { "Accept": "text/html,*/*", "Referer": referer || embedUrl, "User-Agent": USER_AGENT }
  }).then(function (html) {
    var unpacked = unpackPacker(html);
    var match = unpacked.match(/wurl.*?=.*?["']([^"']+)["'];?/i);
    if (!match) return [];
    var streamUrl = String(match[1] || "");
    if (/^\/\//.test(streamUrl)) streamUrl = "https:" + streamUrl;
    if (!/^https?:\/\//i.test(streamUrl)) return [];
    return [{ url: streamUrl, referer: embedUrl, label: "MixDrop" }];
  }).catch(function () { return []; });
}

function isHgCloud(url) {
  return /^(?:www\.)?(?:hgcloud\.to|hglink\.to|dhcplay\.com|gradehgplus\.com|hanerix\.com|audinifer\.com|vibuxer\.com)$/i.test(hostOf(url));
}

function packedPlayerStreams(response, label) {
  var unpacked = unpackPacker(response.text);
  var candidates = {};
  var re = /["']?(?:hls[234]|file)["']?\s*:\s*["']([^"']+)["']/gi;
  var match;
  while ((match = re.exec(unpacked))) {
    var value = decodeHtmlEntities(match[1]).replace(/\\u0026/gi, "&").replace(/\\u003d/gi, "=");
    var url = absoluteUrl(response.url, value);
    // HGCloud hls3 may be an obfuscated master.txt; use native playlists only.
    if (/^https?:\/\//i.test(url) && /\.m3u8$/i.test(url.split(/[?#]/)[0])) candidates[url] = true;
  }
  if (!Object.keys(candidates).length) mediaUrlsFromText(unpacked, response.url).forEach(function (url) { candidates[url] = true; });
  return Object.keys(candidates).map(function (url) {
    return { url: url, referer: response.url, label: label };
  });
}

function resolveStreamWish(url, referer) {
  var hg = isHgCloud(url);
  if (!hg && !/(?:streamwish|wish|filelions|filelion|rapidplayers|dwish|embedwish|flaswish|cdnwish|hlswish|vidhide|vidhidepro|filemoon)/i.test(url)) return Promise.resolve([]);
  function load(target) {
    return fetchResponse(target, {
      headers: { "Accept": "text/html,*/*", "Referer": referer || url, "User-Agent": USER_AGENT }
    }).then(function (response) { return packedPlayerStreams(response, hg ? "HGCloud" : "StreamHost"); }).catch(function () { return []; });
  }
  return load(url).then(function (streams) {
    if (streams.length || !hg || !/^(hgcloud\.to|hglink\.to|dhcplay\.com|gradehgplus\.com)$/i.test(hostOf(url))) return streams;
    var match = String(url).match(/^https?:\/\/[^/]+\/(?:e\/|f\/)?([A-Za-z0-9_-]+)\/?(\?[^#]*)?(?:#.*)?$/);
    if (!match) return [];
    // Native mirrors from the working Cloudstream HGCloud extractor; preserve video ID/query.
    var hosts = ["hanerix.com", "audinifer.com", "vibuxer.com"];
    function next(index) {
      if (index >= hosts.length) return Promise.resolve([]);
      return load("https://" + hosts[index] + "/e/" + match[1] + (match[2] || "")).then(function (found) {
        return found.length ? found : next(index + 1);
      });
    }
    return next(0);
  });
}

function rot13(value) {
  return String(value || "").replace(/[a-zA-Z]/g, function (c) {
    var code = c.charCodeAt(0);
    var base = code <= 90 ? 65 : 97;
    return String.fromCharCode(((code - base + 13) % 26) + base);
  });
}

function base64DecodeBinary(input) {
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var clean = String(input || "").replace(/[^A-Za-z0-9+/=]/g, "");
  var output = "";
  var i = 0;
  while (i < clean.length) {
    var e1 = chars.indexOf(clean.charAt(i++));
    var e2 = chars.indexOf(clean.charAt(i++));
    var c3 = clean.charAt(i++);
    var c4 = clean.charAt(i++);
    var e3 = c3 === "=" ? 64 : chars.indexOf(c3);
    var e4 = c4 === "=" ? 64 : chars.indexOf(c4);
    if (e1 < 0 || e2 < 0) break;
    output += String.fromCharCode((e1 << 2) | (e2 >> 4));
    if (e3 !== 64 && e3 >= 0) output += String.fromCharCode(((e2 & 15) << 4) | (e3 >> 2));
    if (e4 !== 64 && e4 >= 0 && e3 >= 0) output += String.fromCharCode(((e3 & 3) << 6) | e4);
  }
  return output;
}

function binaryToUtf8(binary) {
  try {
    var encoded = "";
    for (var i = 0; i < binary.length; i++) encoded += "%" + ("0" + binary.charCodeAt(i).toString(16)).slice(-2);
    return decodeURIComponent(encoded);
  } catch (_) {
    return binary;
  }
}

function decryptVoe(encoded) {
  try {
    var step1 = rot13(encoded);
    ["@$", "^^", "~@", "%?", "*~", "!!", "#&"].forEach(function (pattern) {
      step1 = step1.split(pattern).join("_");
    });
    var step2 = step1.replace(/_/g, "");
    var step3 = base64DecodeBinary(step2);
    var step4 = "";
    for (var i = 0; i < step3.length; i++) step4 += String.fromCharCode(step3.charCodeAt(i) - 3);
    var step5 = step4.split("").reverse().join("");
    return JSON.parse(binaryToUtf8(base64DecodeBinary(step5)));
  } catch (_) {
    return null;
  }
}

function voeJsonPayloads(html) {
  // Read raw script bodies: Android's HTML selector bridge may normalize script text.
  var found = [];
  var scripts = /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi;
  var match;
  while ((match = scripts.exec(String(html || "")))) {
    if (/\btype\s*=\s*(?:["']application\/json["']|application\/json)(?:\s|$)/i.test(match[1])) found.push(match[2].trim());
  }
  return found;
}

function voeMediaUrl(value, base) {
  // Accept decoder-owned source fields even when the current engine omits .m3u8/.mp4.
  // Do not scrape arbitrary page URLs: Voe embeds a dummy test video on the same page.
  var raw = String(value || "").trim(); // JSON.parse already decoded escapes; signed fields must remain exact.
  if (!raw || /^(?!https?:)[a-z][a-z0-9+.-]*:/i.test(raw)) return "";
  var url = /^https?:\/\//i.test(raw) ? raw : absoluteUrl(base, raw);
  return /^https?:\/\//i.test(url) ? url : "";
}

function resolveVoe(url, referer) {
  if (!/(?:voe\.|tubeless|simpulum|urochs|nathanfromsubject|yip\.su|metagnath|donaldlineelse|charlestoughrace|jeremyparticipantanything)/i.test(hostOf(url))) return Promise.resolve([]);
  function load(target, depth) {
    return fetchResponse(target, {
      headers: { "Accept": "text/html,*/*", "Referer": referer || url, "User-Agent": USER_AGENT }
    }).then(function (response) {
      var redirect = response.text.match(/window\.location(?:\.href)?\s*=\s*["'](https?:\/\/[^"']+)["']/i);
      if (redirect && depth < 2 && redirect[1] !== response.url) return load(absoluteUrl(response.url, redirect[1]), depth + 1);
      return response;
    });
  }
  return load(url, 0).then(function (response) {
    var out = [];
    var seen = {};
    voeJsonPayloads(response.text).forEach(function (raw) {
      var encoded = raw;
      try {
        var parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) encoded = String(parsed[0] || "");
        else if (typeof parsed === "string") encoded = parsed;
        else return;
      } catch (_) { return; }
      var data = decryptVoe(encoded);
      if (!data) return;
      function add(value, label, hls) {
        var media = voeMediaUrl(value, response.url);
        if (!media || seen[media]) return;
        seen[media] = true;
        out.push({ url: media, referer: hls ? "https://voe.sx/" : url, label: label, voe: true,
          mimeType: hls ? "application/x-mpegURL" : null,
          headers: hls ? { "Origin": "https://voe.sx/" } : {} });
      }
      add(data.source, "VOE", true);
      add(data.direct_access_url, "VOE MP4", false);
    });
    console.log("[PencuriMovie] VOE decoded sources=" + out.length);
    return out;
  }).catch(function () { return []; });
}

function collectMediaFromObject(value, baseUrl, out, depth) {
  if (depth > 7 || value == null) return;
  if (typeof value === "string") {
    var clean = decodeHtmlEntities(value).replace(/\\\//g, "/").trim();
    if (/^https?:\/\//i.test(clean) && isLikelyStreamUrl(clean)) out[clean] = true;
    mediaUrlsFromText(clean, baseUrl).forEach(function (url) { out[url] = true; });
    return;
  }
  if (Array.isArray(value)) {
    value.forEach(function (x) { collectMediaFromObject(x, baseUrl, out, depth + 1); });
    return;
  }
  if (typeof value === "object") {
    Object.keys(value).forEach(function (key) {
      var child = value[key];
      if (typeof child === "string" && /^(?:file|url|src|source|stream|playlist|hls|video)$/i.test(key)) {
        var candidate = decodeHtmlEntities(child).replace(/\\\//g, "/").trim();
        if (/^https?:\/\//i.test(candidate) && isLikelyStreamUrl(candidate)) out[candidate] = true;
      }
      collectMediaFromObject(child, baseUrl, out, depth + 1);
    });
  }
}

function resolveAbyss(url) {
  if (!/(?:abyss\.|playhydrax\.com)/i.test(url)) return Promise.resolve([]);
  return fetchText(url, {
    headers: { "Accept": "text/html,*/*", "Origin": originOf(url), "Referer": originOf(url) + "/", "User-Agent": USER_AGENT }
  }).then(function (html) {
    var match = html.match(/const\s+datas\s*=\s*"([^"]+)"/i) || html.match(/datas\s*[:=]\s*'([^']+)'/i);
    if (!match) return [];
    return fetchJson("https://enc-dec.app/api/dec-abyss", {
      method: "POST",
      headers: { "Accept": "application/json", "Content-Type": "application/json", "User-Agent": USER_AGENT },
      body: JSON.stringify({ text: match[1] })
    }).then(function (data) {
      if (!data || Number(data.status) !== 200) return [];
      var found = {};
      collectMediaFromObject(data.result, url, found, 0);
      return Object.keys(found).map(function (streamUrl) {
        return { url: streamUrl, referer: url, label: "Abyss" };
      });
    });
  }).catch(function () { return []; });
}

function resolveStreamTape(url, referer) {
  if (!/(?:streamtape|strtape|stape|shavetape|streamta\.pe)/i.test(url)) return Promise.resolve([]);
  return fetchText(url, {
    headers: { "Accept": "text/html,*/*", "Referer": referer || url, "User-Agent": USER_AGENT }
  }).then(function (html) {
    var clean = String(html || "").replace(/\\\//g, "/");
    var match = clean.match(/id=["']robotlink["'][^>]*>([^<]+)/i) ||
      clean.match(/id=["']norobotlink["'][^>]*>([^<]+)/i) ||
      clean.match(/(?:robotlink|norobotlink).*?innerHTML\s*=\s*['"]([^'"]+)/i);
    if (!match) return [];
    var streamUrl = String(match[1] || "").trim();
    if (/^\/\//.test(streamUrl)) streamUrl = "https:" + streamUrl;
    if (!/^https?:\/\//i.test(streamUrl)) return [];
    return [{ url: streamUrl, referer: url, label: "StreamTape" }];
  }).catch(function () { return []; });
}

function nestedFramesFromHtml(html, pageUrl) {
  var cheerio = getCheerio();
  var $ = cheerio.load(html);
  var found = {};
  function add(raw) {
    var url = absoluteUrl(pageUrl, raw);
    if (!url || url === pageUrl || isBlockedFrame(url)) return;
    found[url] = true;
  }
  $("iframe[src], iframe[data-src], [data-video], [data-url], [data-embed], [data-link]").each(function (_, el) {
    var node = $(el);
    add(node.attr("data-src") || node.attr("src") || node.attr("data-video") || node.attr("data-url") || node.attr("data-embed") || node.attr("data-link"));
  });
  return Object.keys(found).slice(0, 4);
}

function resolveGeneric(url, referer, depth) {
  if (isLikelyStreamUrl(url)) {
    return Promise.resolve([{ url: url, referer: referer || originOf(url) + "/", label: "Direct" }]);
  }
  if (depth > 1) return Promise.resolve([]);

  return fetchResponse(url, {
    headers: { "Accept": "text/html,*/*", "Referer": referer || originOf(url) + "/", "User-Agent": USER_AGENT }
  }).then(function (response) {
    var finalUrl = response.url || url;
    var unpacked = unpackPacker(response.text);
    var direct = mediaUrlsFromText(unpacked, finalUrl).map(function (streamUrl) {
      return { url: streamUrl, referer: finalUrl, label: "Direct" };
    });
    if (direct.length) return direct;

    var frames = nestedFramesFromHtml(response.text, finalUrl);
    if (!frames.length) return [];
    return Promise.all(frames.map(function (frame) {
      return resolveMirror({ url: frame, label: "Nested" }, finalUrl, depth + 1);
    })).then(function (groups) {
      var out = [];
      groups.forEach(function (group) { out = out.concat(group || []); });
      return out;
    });
  }).catch(function () { return []; });
}

function mirrorPriority(mirror) {
  var value = (String(mirror && mirror.label || "") + " " + String(mirror && mirror.url || "")).toLowerCase();
  if (isLikelyStreamUrl(mirror.url)) return 0;
  if (/playmate|playm/.test(value)) return 1;
  if (isHgCloud(mirror.url) || /streamwish|wish|filelion|vidhide|filemoon/.test(value)) return 2;
  if (/voe/.test(value)) return 3;
  if (/mixdrop|mxdrop/.test(value)) return 4;
  if (/dsvplay|dood/.test(value)) return 5;
  if (/streamtape|stape/.test(value)) return 6;
  if (/abyss|playhydrax/.test(value)) return 7;
  return 10;
}

function resolveMirror(mirror, pageUrl, depth) {
  var url = String(mirror && mirror.url || "");
  if (!url) return Promise.resolve([]);
  var host = hostOf(url);

  function finish(streams) {
    return (streams || []).map(function (stream) {
      if (!stream.label || stream.label === "Direct" || stream.label === "Nested") {
        stream.label = mirror.label || stream.label || host || "Server";
      }
      return stream;
    });
  }

  return resolvePlaymate(url)
    .then(function (streams) { return streams.length ? streams : resolveStreamWish(url, pageUrl); })
    .then(function (streams) { return streams.length ? streams : resolveVoe(url, pageUrl); })
    .then(function (streams) { return streams.length ? streams : resolveMixDrop(url, pageUrl); })
    .then(function (streams) { return streams.length ? streams : resolveDood(url, pageUrl); })
    .then(function (streams) { return streams.length ? streams : resolveStreamTape(url, pageUrl); })
    .then(function (streams) { return streams.length ? streams : resolveAbyss(url); })
    .then(function (streams) { return streams.length ? streams : resolveGeneric(url, pageUrl, depth || 0); })
    .then(function (streams) {
      if (!streams.length) console.log("[PencuriMovie] unresolved host=" + (host || "?") + " url=" + url);
      return finish(streams);
    });
}

function qualityFromUrl(url) {
  var value = String(url || "").toLowerCase();
  var m = value.match(/(?:^|[^0-9])(2160|1440|1080|720|480|360)p?(?:[^0-9]|$)/);
  if (m) return m[1] + "p";
  if (/4k/.test(value)) return "2160p";
  return "Auto";
}

function formatStreams(streams) {
  var seen = {};
  var out = [];

  streams.forEach(function (stream) {
    var url = String(stream && stream.url || "").trim();
    var key = String(stream.choiceId || "") + "|" + url;
    if (!url || seen[key]) return;
    seen[key] = true;

    var quality = stream.hlsVerified ? "Auto" : qualityFromUrl(url);
    var label = String(stream.label || "Server").trim();
    var headers = checkHeaders(stream);

    out.push({
      name: PROVIDER,
      title: label + " • " + quality + " • MalaySub",
      url: url,
      quality: quality,
      headers: headers,
      mimeType: stream.hlsVerified ? "application/x-mpegURL" : (stream.mimeType || undefined)
    });
  });

  return out;
}

// The same short validation budget applies to every host/candidate.
const MEDIA_CHECK_MS = 2000;
function checkedRequest(url, options, read) {
  var controller = typeof AbortController === "function" ? new AbortController() : null;
  var opts = Object.assign({}, options || {});
  if (controller) opts.signal = controller.signal;
  var cancel;
  var request = new Promise(function (resolve) {
    var settled = false;
    var timer;
    cancel = function () {
      if (settled) return;
      settled = true; clearTimeout(timer);
      if (controller) controller.abort();
      resolve(null);
    };
    timer = setTimeout(function () {
      if (settled) return;
      settled = true;
      if (controller) controller.abort();
      resolve(null);
    }, MEDIA_CHECK_MS);
    Promise.resolve().then(function () { return fetch(url, opts); }).then(read).then(function (result) {
      if (settled) return;
      settled = true; clearTimeout(timer); resolve(result);
    }, function () {
      if (settled) return;
      settled = true; clearTimeout(timer); resolve(null);
    });
  });
  request.cancel = function () { cancel(); };
  return request;
}

function checkHeaders(stream) {
  var headers = Object.assign({}, stream.headers || {});
  if (!headers["User-Agent"]) headers["User-Agent"] = USER_AGENT;
  if (!headers.Accept) headers.Accept = "*/*";
  if (stream.noReferer) { delete headers.Referer; delete headers.referer; }
  else if (!headers.Referer && !headers.referer) headers.Referer = stream.referer || originOf(stream.url) + "/";
  return headers;
}

function isHlsStream(stream) {
  return /\.m3u8(?:[?#]|$)|\/engine\/hls\d*\//i.test(stream.url) || String(stream.label || "").toUpperCase() === "VOE";
}

function checkMedia(stream, hls) {
  var headers = checkHeaders(stream);
  if (!hls) headers.Range = "bytes=0-0";
  return checkedRequest(stream.url, { headers: headers }, function (res) {
    if (!res || (res.status !== 200 && res.status !== 206)) return null;
    if (hls) return res.text().then(function (body) {
      var text = String(body || "").replace(/^\uFEFF/, "").trim();
      if (!/^#EXTM3U(?:\r?\n|$)/.test(text)) return null;
      var media = /^#EXTINF:/m.test(text) && /^(?!#)\S+/m.test(text);
      var lines = text.split(/\r?\n/).map(function (line) { return line.trim(); });
      var master = lines.some(function (line, index) {
        if (!/^#EXT-X-STREAM-INF:/.test(line)) return false;
        var next = index + 1;
        while (next < lines.length && (!lines[next] || lines[next][0] === "#")) next++;
        return next < lines.length && !/^(?!https?:)[a-z][a-z0-9+.-]*:/i.test(lines[next]) && /^https?:\/\//i.test(absoluteUrl(res.url || stream.url, lines[next]));
      });
      if (!media && !master) return null;
      // Keep Auto master playback, as Cloudstream generateM3u8(returnThis=true) does.
      // Use the actual HTTP response URL when VOE redirects a signed playlist.
      var verifiedUrl = stream.voe && /^https?:\/\//i.test(res.url || "") ? res.url : stream.url;
      return Object.assign({}, stream, { url: verifiedUrl, hlsVerified: true });
    });
    var type = res.headers && res.headers.get ? String(res.headers.get("content-type") || "").toLowerCase() : "";
    var range = res.headers && res.headers.get ? String(res.headers.get("content-range") || "") : "";
    var total = range.match(/\/(\d+)$/);
    if (res.body && typeof res.body.cancel === "function") Promise.resolve(res.body.cancel()).catch(function () {});
    if (!/^video\//.test(type) && !(/^application\/octet-stream/.test(type) && total && Number(total[1]) >= 65536)) return null;
    return stream;
  });
}

function firstChecked(candidates, hls) {
  // First valid response wins within this website choice only. Empty/error cannot win.
  return new Promise(function (resolve) {
    if (!candidates.length) { resolve(null); return; }
    var pending = candidates.length;
    var won = false;
    var probes = candidates.map(function (stream) { return checkMedia(stream, hls); });
    probes.forEach(function (probe) {
      probe.then(function (checked) {
        if (checked && !won) {
          won = true; resolve(checked);
          probes.forEach(function (other) { if (other !== probe && other.cancel) other.cancel(); });
        }
        pending--;
        if (!pending && !won) resolve(null);
      }).catch(function () { pending--; if (!pending && !won) resolve(null); });
    });
  });
}

function selectServerStream(streams, mirror, ordinal) {
  var seen = Object.create(null);
  var unique = (streams || []).filter(function (stream) {
    if (!stream || !/^https?:\/\//i.test(stream.url) || seen[stream.url]) return false;
    seen[stream.url] = true; return true;
  });
  var hls = unique.filter(isHlsStream);
  var direct = unique.filter(function (stream) { return !isHlsStream(stream); });
  return firstChecked(hls, true).then(function (winner) {
    return winner || firstChecked(direct, false);
  }).then(function (winner) {
    if (!winner) return [];
    var extractor = String(winner.label || "Server").replace(/\s+MP4$/i, "");
    if (/^(Direct|Nested|Server|Script)$/i.test(extractor)) extractor = hostOf(mirror.url) || "Server";
    if (/^dood$/i.test(extractor)) extractor = "DoodStream";
    if (/^voe$/i.test(extractor)) extractor = "Voe";
    var label = String(mirror.label || "").trim();
    var number = label.match(/^server[\s_-]*(\d+)$/i);
    var name = number ? extractor + " " + number[1] : !label || /^(Server|Script)$/i.test(label) ? extractor + " " + ordinal : label.toLowerCase() === extractor.toLowerCase() ? extractor + " " + ordinal : label + " • " + extractor;
    winner.label = name;
    winner.choiceId = mirror.url;
    return [winner];
  });
}

function resolveMirrors(mirrors, pageUrl) {
  var selected = (mirrors || []).slice().sort(function (a, b) {
    return mirrorPriority(a) - mirrorPriority(b);
  });

  console.log("[PencuriMovie] mirrors=" + mirrors.length);
  console.log("[PencuriMovie] mirror hosts=" + selected.map(function (x) {
    return hostOf(x.url) + "[" + String(x.label || "") + "]";
  }).join(" | "));

  return Promise.all(selected.map(function (mirror) {
    return resolveMirror(mirror, pageUrl, 0).then(function (streams) {
      return selectServerStream(streams, mirror, (mirrors || []).indexOf(mirror) + 1);
    }).catch(function () { return []; });
  })).then(function (groups) {
    var flat = [];
    groups.forEach(function (group) { flat = flat.concat(group || []); });
    return flat;
  });
}

function getStreams(tmdbId, mediaType, season, episode) {
  mediaType = mediaType === "tv" ? "tv" : "movie";
  season = Number(season || 1);
  episode = Number(episode || 1);

  console.log("[PencuriMovie] TMDB=" + tmdbId + " type=" + mediaType + (mediaType === "tv" ? " S" + season + "E" + episode : ""));
  console.log("[PencuriMovie] base=" + BASE);

  return getTmdbDetails(tmdbId, mediaType)
    .then(function (details) {
      return findTitle(details, mediaType);
    })
    .then(function (item) {
      if (!item) {
        console.log("[PencuriMovie] title not found");
        return null;
      }
      return loadPlaybackPage(item, mediaType, season, episode);
    })
    .then(function (playback) {
      if (!playback) return [];
      var mirrors = collectEmbedUrls(playback.html, playback.url);
      return resolveMirrors(mirrors, playback.url);
    })
    .then(function (resolved) {
      var streams = formatStreams(resolved || []);
      console.log("[PencuriMovie] v" + VERSION + " checked sources=" + streams.length);
      return streams;
    })
    .catch(function (error) {
      console.log("[PencuriMovie] error=" + (error && error.message ? error.message : String(error)));
      return [];
    });
}

module.exports = { getStreams };
