# Bootstrap patch

Target repository: `Luckez12/Test-Plugin`

This patch adds a Nuvio provider development workspace without changing the existing `d/` directory.

After extraction at the repository root:

```bash
npm install
npm run create -- firstprovider "First Provider"
npm run build -- firstprovider
npm run test:provider -- firstprovider 872585 movie
```

The generated provider is disabled in `manifest.json` until it is ready.
