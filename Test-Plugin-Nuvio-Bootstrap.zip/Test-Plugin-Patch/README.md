# Test-Plugin

Nuvio provider workspace for `Luckez12/Test-Plugin`.

## Setup

```bash
npm install
```

## Create the first provider

```bash
npm run create -- firstprovider "First Provider"
```

This creates:

```text
src/firstprovider/
  index.js
  config.js
  http.js
  search.js
  extractor.js
```

It also adds the provider to `manifest.json` as disabled.

## Provider workflow

`getStreams(tmdbId, mediaType, season, episode)` calls:

```text
search.js -> extractor.js -> normalised stream array
```

Implement the source-specific logic mainly in `search.js`, `extractor.js`, and `http.js`.

Expected stream shape:

```js
{
  name: 'Provider Name',
  title: '1080p',
  url: 'https://example.com/video.m3u8',
  quality: '1080p',
  size: '2.1 GB',
  headers: {
    Referer: 'https://example.com/'
  }
}
```

`size` and `headers` are optional.

## Build

```bash
npm run build -- firstprovider
```

Output:

```text
providers/firstprovider.js
```

Build all providers:

```bash
npm run build
```

Production minified build:

```bash
node build.js --minify firstprovider
```

## Local test

```bash
npm run test:provider -- firstprovider 872585 movie
```

TV example:

```bash
npm run test:provider -- firstprovider 1396 tv 1 1
```

## Local Nuvio plugin server

```bash
npm start
```

Use this manifest URL in Nuvio Developer Plugin Tester:

```text
http://YOUR-PC-LAN-IP:3000/manifest.json
```

## Publish through GitHub

Build the provider, set `enabled` to `true` in `manifest.json`, commit `providers/<id>.js`, then push.

Repository manifest URL:

```text
https://raw.githubusercontent.com/Luckez12/Test-Plugin/refs/heads/main/manifest.json
```
