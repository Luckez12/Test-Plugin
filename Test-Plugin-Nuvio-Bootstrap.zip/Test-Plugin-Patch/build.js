const fs = require('fs');
const path = require('path');
const esbuild = require('esbuild');

const ROOT = __dirname;
const SRC_DIR = path.join(ROOT, 'src');
const OUT_DIR = path.join(ROOT, 'providers');
const args = process.argv.slice(2);
const minify = args.includes('--minify');
const requested = args.filter((arg) => !arg.startsWith('--'));

function listProviders() {
  if (!fs.existsSync(SRC_DIR)) return [];
  return fs.readdirSync(SRC_DIR, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && !entry.name.startsWith('_'))
    .map((entry) => entry.name)
    .filter((name) => fs.existsSync(path.join(SRC_DIR, name, 'index.js')));
}

async function buildProvider(name) {
  const entry = path.join(SRC_DIR, name, 'index.js');
  if (!fs.existsSync(entry)) {
    throw new Error(`Provider source not found: src/${name}/index.js`);
  }

  fs.mkdirSync(OUT_DIR, { recursive: true });

  await esbuild.build({
    entryPoints: [entry],
    outfile: path.join(OUT_DIR, `${name}.js`),
    bundle: true,
    format: 'cjs',
    platform: 'neutral',
    target: ['es2016'],
    minify,
    legalComments: 'none',
    external: ['axios', 'cheerio-without-node-native', 'crypto-js']
  });

  console.log(`Built providers/${name}.js${minify ? ' (minified)' : ''}`);
}

async function main() {
  const providers = requested.length ? requested : listProviders();

  if (!providers.length) {
    console.log('No providers to build. Create one with: npm run create -- <provider-id> "Provider Name"');
    return;
  }

  for (const provider of providers) {
    await buildProvider(provider);
  }
}

main().catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
