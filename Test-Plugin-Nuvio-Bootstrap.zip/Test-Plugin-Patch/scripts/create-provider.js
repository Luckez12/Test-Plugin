const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const TEMPLATE = path.join(ROOT, 'src', '_template');
const manifestPath = path.join(ROOT, 'manifest.json');

const id = String(process.argv[2] || '').trim().toLowerCase();
const name = String(process.argv[3] || id).trim();

if (!/^[a-z0-9][a-z0-9-_]*$/.test(id)) {
  console.error('Usage: npm run create -- <provider-id> "Provider Name"');
  console.error('Provider id may contain lowercase letters, numbers, hyphens and underscores.');
  process.exit(1);
}

const target = path.join(ROOT, 'src', id);
if (fs.existsSync(target)) {
  console.error(`src/${id} already exists.`);
  process.exit(1);
}

fs.cpSync(TEMPLATE, target, { recursive: true });

for (const file of fs.readdirSync(target)) {
  const filePath = path.join(target, file);
  if (!fs.statSync(filePath).isFile()) continue;
  const updated = fs.readFileSync(filePath, 'utf8')
    .replaceAll('__PROVIDER_ID__', id)
    .replaceAll('__PROVIDER_NAME__', name.replaceAll("'", "\\'"));
  fs.writeFileSync(filePath, updated);
}

let manifest = [];
if (fs.existsSync(manifestPath)) {
  manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
}

manifest.push({
  id,
  name,
  description: `${name} provider for Nuvio.`,
  version: '0.1.0',
  author: 'Luckez12',
  supportedTypes: ['movie', 'tv'],
  filename: `providers/${id}.js`,
  enabled: false,
  logo: '',
  contentLanguage: ['en'],
  formats: ['m3u8', 'mp4', 'mkv'],
  limited: false,
  disabledPlatforms: [],
  supportsExternalPlayer: true
});

fs.writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
console.log(`Created src/${id} and registered it in manifest.json`);
console.log(`Next: npm run build -- ${id}`);
