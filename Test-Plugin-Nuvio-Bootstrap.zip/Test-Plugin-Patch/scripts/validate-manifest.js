const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const manifestPath = path.join(ROOT, 'manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

if (!Array.isArray(manifest)) {
  throw new Error('manifest.json must contain an array.');
}

const ids = new Set();
let errors = 0;

for (const entry of manifest) {
  const required = ['id', 'name', 'version', 'supportedTypes', 'filename', 'enabled'];
  for (const key of required) {
    if (entry[key] == null) {
      console.error(`[${entry.id || 'unknown'}] Missing ${key}`);
      errors++;
    }
  }

  if (ids.has(entry.id)) {
    console.error(`[${entry.id}] Duplicate id`);
    errors++;
  }
  ids.add(entry.id);

  const providerFile = path.join(ROOT, entry.filename || '');
  if (entry.enabled && !fs.existsSync(providerFile)) {
    console.error(`[${entry.id}] Enabled provider file does not exist: ${entry.filename}`);
    errors++;
  }
}

if (errors) {
  process.exitCode = 1;
} else {
  console.log(`manifest.json OK (${manifest.length} provider${manifest.length === 1 ? '' : 's'})`);
}
