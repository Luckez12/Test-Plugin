export const PROVIDER = {
  id: '__PROVIDER_ID__',
  name: '__PROVIDER_NAME__',
  baseUrl: 'https://example.com'
};
