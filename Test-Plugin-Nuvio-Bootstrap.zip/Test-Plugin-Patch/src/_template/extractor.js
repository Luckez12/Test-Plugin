import { PROVIDER } from './config.js';

export async function extractStreams(media) {
  // Replace this with the real player/embed extraction logic.
  // Nuvio expects an array of stream objects.
  console.log(`[${PROVIDER.name}] extractor placeholder`, media);
  return [];
}
