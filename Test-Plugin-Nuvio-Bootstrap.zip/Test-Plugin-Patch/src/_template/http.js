const DEFAULT_HEADERS = {
  'User-Agent': 'Mozilla/5.0',
  'Accept': '*/*'
};

export function request(url, options = {}) {
  const headers = Object.assign({}, DEFAULT_HEADERS, options.headers || {});

  return fetch(url, Object.assign({}, options, { headers })).then((response) => {
    if (!response.ok) {
      throw new Error(`HTTP ${response.status} for ${url}`);
    }
    return response;
  });
}

export function getText(url, options = {}) {
  return request(url, options).then((response) => response.text());
}

export function getJson(url, options = {}) {
  return request(url, options).then((response) => response.json());
}
