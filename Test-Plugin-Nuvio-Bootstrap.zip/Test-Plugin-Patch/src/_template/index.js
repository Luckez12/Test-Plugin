import { PROVIDER } from './config.js';
import { searchMedia } from './search.js';
import { extractStreams } from './extractor.js';

function normaliseStreams(streams) {
  if (!Array.isArray(streams)) return [];

  return streams
    .filter((stream) => stream && typeof stream.url === 'string' && stream.url.length > 0)
    .map((stream) => ({
      name: stream.name || PROVIDER.name,
      title: stream.title || stream.quality || PROVIDER.name,
      url: stream.url,
      quality: stream.quality || 'Unknown',
      ...(stream.size ? { size: stream.size } : {}),
      ...(stream.headers ? { headers: stream.headers } : {})
    }));
}

async function getStreams(tmdbId, mediaType, season, episode) {
  try {
    console.log(`[${PROVIDER.name}] ${mediaType} TMDB:${tmdbId}`);
    const media = await searchMedia(tmdbId, mediaType, season, episode);
    const streams = await extractStreams(media);
    return normaliseStreams(streams);
  } catch (error) {
    console.error(`[${PROVIDER.name}]`, error && error.message ? error.message : error);
    return [];
  }
}

module.exports = { getStreams };
