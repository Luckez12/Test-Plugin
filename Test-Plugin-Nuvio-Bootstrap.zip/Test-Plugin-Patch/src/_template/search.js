import { PROVIDER } from './config.js';

export async function searchMedia(tmdbId, mediaType, season, episode) {
  // Replace this with the source site's search or metadata lookup.
  // Return enough data for extractor.js to locate the playable source.
  return {
    tmdbId: String(tmdbId),
    mediaType,
    season: season == null ? null : Number(season),
    episode: episode == null ? null : Number(episode),
    provider: PROVIDER.id
  };
}
