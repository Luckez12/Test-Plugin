const path = require('path');

const providerId = process.argv[2];
const tmdbId = process.argv[3] || '872585';
const mediaType = process.argv[4] || 'movie';
const season = process.argv[5];
const episode = process.argv[6];

if (!providerId) {
  console.error('Usage: npm run test:provider -- <provider-id> [tmdbId] [movie|tv] [season] [episode]');
  process.exit(1);
}

const providerPath = path.resolve(__dirname, '..', 'providers', `${providerId}.js`);
const provider = require(providerPath);

if (!provider || typeof provider.getStreams !== 'function') {
  throw new Error(`${providerId} does not export getStreams()`);
}

Promise.resolve(provider.getStreams(tmdbId, mediaType, season, episode))
  .then((streams) => {
    if (!Array.isArray(streams)) {
      throw new Error('getStreams() must resolve to an array.');
    }

    const invalid = streams.filter((stream) => !stream || typeof stream.url !== 'string');
    console.log(`Streams found: ${streams.length}`);
    if (invalid.length) {
      throw new Error(`${invalid.length} invalid stream object(s) found.`);
    }
    if (streams.length) console.dir(streams, { depth: 5 });
  })
  .catch((error) => {
    console.error(error.stack || error.message || error);
    process.exit(1);
  });
